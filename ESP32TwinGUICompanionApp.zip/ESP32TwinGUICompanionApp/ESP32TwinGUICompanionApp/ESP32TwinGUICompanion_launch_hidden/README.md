This program scans for the ESP32TwinGUI board,
automatically registers it and its serial port
and then sends it the average CPU temp and load,
average GPU temp and load, and the datetime.

Make sure you download the entire 
ESP32TwinGUICompanionApp folder because the app
requires the .dll files as well as the icon and
splashscreen image to run properly!!!!
